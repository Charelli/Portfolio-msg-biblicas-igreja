# Mensagens App

Este projeto é uma aplicação web simples para cadastro e busca de mensagens, com integração a uma API de Bíblia online. A aplicação permite que os usuários cadastrem mensagens, busquem por elas, filtrem por livros da Bíblia e visualizem detalhes de cada mensagem.

## Estrutura do Projeto

```
mensagens-app
├── src
│   ├── index.html          # Estrutura principal da aplicação
│   ├── app.js              # Lógica principal da aplicação
│   ├── styles.css          # Estilos CSS para a aplicação
│   ├── components          # Componentes da aplicação
│   │   ├── cadastro.js     # Formulário de cadastro de mensagens
│   │   ├── busca.js        # Funcionalidade de busca de mensagens
│   │   ├── lista.js        # Exibição da lista de mensagens
│   │   ├── filtro.js       # Filtro de mensagens por livro da Bíblia
│   │   └── detalhes.js     # Exibição de detalhes de uma mensagem
│   └── utils               # Funções utilitárias
│       └── biblia-api.js   # Integração com API de Bíblia online
├── README.md               # Documentação do projeto
```

## Funcionalidades

- **Cadastro de Mensagens**: Permite que os usuários cadastrem mensagens com título, referência bíblica e texto.
- **Busca de Mensagens**: Os usuários podem buscar mensagens cadastradas por título, pregador, data ou versículo.
- **Lista de Mensagens**: Exibe todas as mensagens cadastradas em ordem de data.
- **Filtro por Bíblia**: Permite filtrar mensagens com base no livro da Bíblia.
- **Visualização de Detalhes**: Mostra detalhes de uma mensagem específica ao clicar nela.
- **Integração com Bíblia Online**: Abre referências bíblicas em um link externo.

## Instalação

1. Clone o repositório:
   ```
   git clone <URL_DO_REPOSITORIO>
   ```
2. Navegue até o diretório do projeto:
   ```
   cd mensagens-app
   ```
3. Abra o arquivo `src/index.html` em um navegador para visualizar a aplicação.

## Uso

- Acesse a aplicação em um navegador.
- Utilize o formulário de cadastro para adicionar novas mensagens.
- Use a barra de busca para encontrar mensagens específicas.
- Aplique filtros para visualizar mensagens de livros específicos da Bíblia.
- Clique em uma mensagem na lista para ver seus detalhes.

## Contribuição

Sinta-se à vontade para contribuir com melhorias ou correções. Faça um fork do repositório e envie suas alterações através de um pull request.